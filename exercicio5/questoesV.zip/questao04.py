qtd = 0
for i in range(18643,33087):
    if('2' in str(i) and '7' not in str(i)):
        qtd += 1

print qtd
