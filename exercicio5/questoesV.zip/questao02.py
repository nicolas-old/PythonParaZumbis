qtd = 0
for i in range(9):
    if i!= 3:
        for j in range(6):
            print('oi')
            qtd+=1
print qtd
